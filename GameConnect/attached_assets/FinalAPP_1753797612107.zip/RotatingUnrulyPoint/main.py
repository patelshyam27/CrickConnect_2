from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import os
from datetime import datetime
import google_auth_oauthlib.flow
import google.oauth2.credentials
import json
import requests

app = Flask(__name__)
app.secret_key = 'cricket_lovers_secret_key_2024'

# Google OAuth configuration
GOOGLE_CLIENT_ID = os.environ.get('GOOGLE_CLIENT_ID', '')
GOOGLE_CLIENT_SECRET = os.environ.get('GOOGLE_CLIENT_SECRET', '')

# Owner credentials
OWNER_USERNAME = "shyam"
OWNER_PASSWORD = "shyam271106"


def create_oauth_flow():
    if GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET:
        redirect_uri = url_for('oauth2callback', _external=True)
        if redirect_uri.startswith('http://'):
            redirect_uri = redirect_uri.replace('http://', 'https://')

        oauth_config = {
            "web": {
                "client_id": GOOGLE_CLIENT_ID,
                "client_secret": GOOGLE_CLIENT_SECRET,
                "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                "token_uri": "https://oauth2.googleapis.com/token",
                "redirect_uris": [redirect_uri]
            }
        }

        flow = google_auth_oauthlib.flow.Flow.from_client_config(
            oauth_config,
            scopes=[
                "https://www.googleapis.com/auth/userinfo.email",
                "openid",
                "https://www.googleapis.com/auth/userinfo.profile",
            ])
        flow.redirect_uri = redirect_uri
        return flow
    return None


# Database initialization
def init_db():
    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()

    # Users table
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        name TEXT NOT NULL,
        age INTEGER,
        city TEXT,
        state TEXT,
        area TEXT,
        role TEXT,
        availability TEXT,
        phone TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')

    # Admin requests table
    c.execute('''CREATE TABLE IF NOT EXISTS admin_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        username TEXT NOT NULL,
        email TEXT NOT NULL,
        name TEXT NOT NULL,
        reason TEXT,
        status TEXT DEFAULT 'pending',
        requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        approved_at TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id)
    )''')

    # Approved admins table
    c.execute('''CREATE TABLE IF NOT EXISTS approved_admins (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        username TEXT NOT NULL,
        email TEXT NOT NULL,
        approved_by TEXT DEFAULT 'owner',
        approved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id)
    )''')

    # Admin registrations table
    c.execute('''CREATE TABLE IF NOT EXISTS admin_registrations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        name TEXT NOT NULL,
        phone TEXT,
        city TEXT,
        state TEXT,
        area TEXT,
        experience TEXT,
        reason TEXT,
        status TEXT DEFAULT 'pending',
        registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        approved_at TIMESTAMP
    )''')

    # Migration: Add phone column if it doesn't exist
    try:
        c.execute('ALTER TABLE users ADD COLUMN phone TEXT')
    except sqlite3.OperationalError:
        pass

    # Coaching ads table
    c.execute('''CREATE TABLE IF NOT EXISTS coaching_ads (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT,
        area TEXT,
        city TEXT,
        state TEXT,
        coupon_code TEXT,
        discount TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')

    # Live matches table
    c.execute('''CREATE TABLE IF NOT EXISTS live_matches (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        youtube_url TEXT NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')

    # Products table
    c.execute('''CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        price REAL,
        image_url TEXT,
        affiliate_link TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')

    # Connections table for tracking followers/following
    c.execute('''CREATE TABLE IF NOT EXISTS connections (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        follower_id INTEGER,
        following_id INTEGER,
        connected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (follower_id) REFERENCES users (id),
        FOREIGN KEY (following_id) REFERENCES users (id),
        UNIQUE(follower_id, following_id)
    )''')

    # Visitor tracking table
    c.execute('''CREATE TABLE IF NOT EXISTS visitors (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ip_address TEXT,
        user_agent TEXT,
        visited_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')

    conn.commit()
    conn.close()


def is_approved_admin(user_id):
    """Check if user is an approved admin"""
    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()
    c.execute('SELECT id FROM approved_admins WHERE user_id = ?', (user_id, ))
    result = c.fetchone()
    conn.close()
    return result is not None


def is_owner(username, password):
    """Check if credentials match owner"""
    return username == OWNER_USERNAME and password == OWNER_PASSWORD


# Routes
@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))

    # Track visitor
    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()

    visitor_ip = request.remote_addr
    user_agent = request.headers.get('User-Agent', '')

    c.execute(
        '''SELECT id FROM visitors WHERE ip_address = ? 
                 AND visited_at > datetime('now', '-1 hour')''',
        (visitor_ip, ))
    recent_visit = c.fetchone()

    if not recent_visit:
        c.execute(
            'INSERT INTO visitors (ip_address, user_agent) VALUES (?, ?)',
            (visitor_ip, user_agent))

    # Get stats
    c.execute('''SELECT COUNT(DISTINCT ip_address) FROM visitors 
                 WHERE visited_at > datetime('now', '-30 days')''')
    visitor_count = c.fetchone()[0]

    c.execute('SELECT COUNT(*) FROM users')
    user_count = c.fetchone()[0]

    c.execute('''SELECT COUNT(*) FROM visitors 
                 WHERE date(visited_at) = date('now')''')
    today_visits = c.fetchone()[0]

    # Get coaching offers with discounts for homepage
    c.execute('''SELECT * FROM coaching_ads 
                 WHERE coupon_code IS NOT NULL AND coupon_code != '' 
                 AND discount IS NOT NULL AND discount != ''
                 ORDER BY created_at DESC LIMIT 6''')
    coaching_offers = c.fetchall()

    conn.commit()
    conn.close()

    return render_template('index.html',
                           visitor_count=visitor_count,
                           user_count=user_count,
                           today_visits=today_visits,
                           coaching_offers=coaching_offers)


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        data = request.get_json()
        username = data.get('username')
        email = data.get('email')
        password = data.get('password')
        name = data.get('name')
        age = data.get('age')
        city = data.get('city')
        state = data.get('state')
        area = data.get('area')
        role = data.get('role')
        availability = data.get('availability')
        phone = data.get('phone')

        conn = sqlite3.connect('cricket_app.db')
        c = conn.cursor()

        # Check if user exists
        c.execute('SELECT id FROM users WHERE username = ? OR email = ?',
                  (username, email))
        if c.fetchone():
            conn.close()
            return jsonify({
                'success': False,
                'message': 'User already exists'
            })

        # Create user
        hashed_password = generate_password_hash(password)
        c.execute(
            '''INSERT INTO users (username, email, password, name, age, city, state, area, role, availability, phone)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
            (username, email, hashed_password, name, age, city, state, area,
             role, availability, phone))

        user_id = c.lastrowid
        conn.commit()
        conn.close()

        session['user_id'] = user_id
        session['username'] = username
        return jsonify({'success': True, 'message': 'Registration successful'})

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')

        conn = sqlite3.connect('cricket_app.db')
        c = conn.cursor()
        c.execute(
            'SELECT id, username, password FROM users WHERE username = ? OR email = ?',
            (username, username))
        user = c.fetchone()
        conn.close()

        if user and check_password_hash(user[2], password):
            session['user_id'] = user[0]
            session['username'] = user[1]
            return jsonify({'success': True, 'message': 'Login successful'})

        return jsonify({'success': False, 'message': 'Invalid credentials'})

    return render_template('login.html')


@app.route('/owner_login', methods=['GET', 'POST'])
def owner_login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        if is_owner(username, password):
            session['owner'] = True
            session['owner_username'] = username
            return redirect(url_for('owner_dashboard'))
        else:
            flash('Invalid owner credentials')

    return render_template('owner_login.html')


@app.route('/owner_dashboard')
def owner_dashboard():
    if 'owner' not in session:
        return redirect(url_for('owner_login'))

    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()

    # Get pending admin requests
    c.execute('''SELECT ar.*, u.name, u.email FROM admin_requests ar 
                 JOIN users u ON ar.user_id = u.id 
                 WHERE ar.status = 'pending' 
                 ORDER BY ar.requested_at DESC''')
    pending_requests = c.fetchall()

    # Get pending admin registrations
    c.execute(
        '''SELECT * FROM admin_registrations WHERE status = 'pending' ORDER BY registered_at DESC'''
    )
    pending_admin_registrations = c.fetchall()

    # Get approved admin registrations
    c.execute(
        '''SELECT * FROM admin_registrations WHERE status = 'approved' ORDER BY approved_at DESC'''
    )
    approved_admin_registrations = c.fetchall()

    # Get approved admins
    c.execute('''SELECT aa.*, u.name, u.email FROM approved_admins aa 
                 JOIN users u ON aa.user_id = u.id 
                 ORDER BY aa.approved_at DESC''')
    approved_admins = c.fetchall()

    # Get all admin requests history
    c.execute('''SELECT ar.*, u.name, u.email FROM admin_requests ar 
                 JOIN users u ON ar.user_id = u.id 
                 ORDER BY ar.requested_at DESC''')
    all_requests = c.fetchall()

    # Get all admin registrations history
    c.execute(
        '''SELECT * FROM admin_registrations ORDER BY registered_at DESC''')
    all_admin_registrations = c.fetchall()

    conn.close()

    return render_template(
        'owner_dashboard.html',
        pending_requests=pending_requests,
        approved_admins=approved_admins,
        all_requests=all_requests,
        pending_admin_registrations=pending_admin_registrations,
        approved_admin_registrations=approved_admin_registrations,
        all_admin_registrations=all_admin_registrations)


@app.route('/request_admin_access', methods=['GET', 'POST'])
def request_admin_access():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        data = request.get_json()
        reason = data.get('reason', '')

        conn = sqlite3.connect('cricket_app.db')
        c = conn.cursor()

        # Get user info
        c.execute('SELECT username, email, name FROM users WHERE id = ?',
                  (session['user_id'], ))
        user_info = c.fetchone()

        if not user_info:
            conn.close()
            return jsonify({'success': False, 'message': 'User not found'})

        # Check if already requested
        c.execute(
            'SELECT id FROM admin_requests WHERE user_id = ? AND status = "pending"',
            (session['user_id'], ))
        if c.fetchone():
            conn.close()
            return jsonify({
                'success':
                False,
                'message':
                'You already have a pending admin request'
            })

        # Check if already an admin
        if is_approved_admin(session['user_id']):
            conn.close()
            return jsonify({
                'success': False,
                'message': 'You are already an approved admin'
            })

        # Create admin request
        c.execute(
            '''INSERT INTO admin_requests (user_id, username, email, name, reason) 
                     VALUES (?, ?, ?, ?, ?)''',
            (session['user_id'], user_info[0], user_info[1], user_info[2],
             reason))

        conn.commit()
        conn.close()

        return jsonify({
            'success': True,
            'message': 'Admin access request submitted successfully'
        })

    return render_template('request_admin.html')


@app.route('/approve_admin_registration', methods=['POST'])
def approve_admin_registration():
    if 'owner' not in session:
        return jsonify({'success': False, 'message': 'Unauthorized'})

    data = request.get_json()
    registration_id = data.get('registration_id')
    action = data.get('action')  # 'approve' or 'reject'

    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()

    # Get registration details
    c.execute(
        'SELECT * FROM admin_registrations WHERE id = ? AND status = "pending"',
        (registration_id, ))
    admin_registration = c.fetchone()

    if not admin_registration:
        conn.close()
        return jsonify({
            'success': False,
            'message': 'Registration not found or already processed'
        })

    if action == 'approve':
        # Update registration status
        c.execute(
            'UPDATE admin_registrations SET status = "approved", approved_at = CURRENT_TIMESTAMP WHERE id = ?',
            (registration_id, ))
        message = 'Admin registration approved successfully'
    else:
        # Update registration status to rejected
        c.execute(
            'UPDATE admin_registrations SET status = "rejected" WHERE id = ?',
            (registration_id, ))
        message = 'Admin registration rejected'

    conn.commit()
    conn.close()

    return jsonify({'success': True, 'message': message})


@app.route('/approve_admin_request', methods=['POST'])
def approve_admin_request():
    if 'owner' not in session:
        return jsonify({'success': False, 'message': 'Unauthorized'})

    data = request.get_json()
    request_id = data.get('request_id')
    action = data.get('action')  # 'approve' or 'reject'

    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()

    # Get request details
    c.execute(
        'SELECT * FROM admin_requests WHERE id = ? AND status = "pending"',
        (request_id, ))
    admin_request = c.fetchone()

    if not admin_request:
        conn.close()
        return jsonify({
            'success': False,
            'message': 'Request not found or already processed'
        })

    if action == 'approve':
        # Add to approved admins
        c.execute(
            '''INSERT INTO approved_admins (user_id, username, email) 
                     VALUES (?, ?, ?)''',
            (admin_request[1], admin_request[2], admin_request[3]))

        # Update request status
        c.execute(
            'UPDATE admin_requests SET status = "approved", approved_at = CURRENT_TIMESTAMP WHERE id = ?',
            (request_id, ))

        message = 'Admin request approved successfully'
    else:
        # Update request status to rejected
        c.execute('UPDATE admin_requests SET status = "rejected" WHERE id = ?',
                  (request_id, ))
        message = 'Admin request rejected'

    conn.commit()
    conn.close()

    return jsonify({'success': True, 'message': message})


@app.route('/admin_register', methods=['GET', 'POST'])
def admin_register():
    if request.method == 'POST':
        data = request.get_json()
        username = data.get('username')
        email = data.get('email')
        password = data.get('password')
        name = data.get('name')
        phone = data.get('phone')
        city = data.get('city')
        state = data.get('state')
        area = data.get('area')
        experience = data.get('experience')
        reason = data.get('reason')

        conn = sqlite3.connect('cricket_app.db')
        c = conn.cursor()

        # Check if admin already exists
        c.execute(
            'SELECT id FROM admin_registrations WHERE username = ? OR email = ?',
            (username, email))
        if c.fetchone():
            conn.close()
            return jsonify({
                'success':
                False,
                'message':
                'Admin with this username or email already exists'
            })

        # Check if user already exists in regular users
        c.execute('SELECT id FROM users WHERE username = ? OR email = ?',
                  (username, email))
        if c.fetchone():
            conn.close()
            return jsonify({
                'success':
                False,
                'message':
                'This username or email is already registered as a regular user'
            })

        # Create admin registration
        hashed_password = generate_password_hash(password)
        c.execute(
            '''INSERT INTO admin_registrations (username, email, password, name, phone, city, state, area, experience, reason)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
            (username, email, hashed_password, name, phone, city, state, area,
             experience, reason))

        conn.commit()
        conn.close()

        return jsonify({
            'success':
            True,
            'message':
            'Admin registration submitted successfully. Please wait for owner approval.'
        })

    return render_template('admin_register.html')


@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        conn = sqlite3.connect('cricket_app.db')
        c = conn.cursor()

        # Check if admin exists in admin_registrations table
        c.execute(
            'SELECT id, username, password, status FROM admin_registrations WHERE username = ? OR email = ?',
            (username, username))
        admin = c.fetchone()

        if admin and check_password_hash(admin[2], password):
            if admin[3] == 'approved':
                session['admin'] = True
                session['admin_user_id'] = admin[0]
                session['admin_username'] = admin[1]
                conn.close()
                return redirect(url_for('admin_dashboard'))
            elif admin[3] == 'pending':
                conn.close()
                flash(
                    'Your admin registration is pending approval from the owner.'
                )
            else:
                conn.close()
                flash('Your admin registration has been rejected.')
        else:
            conn.close()
            flash('Invalid admin credentials')

    return render_template('admin_login.html')


@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()

    # Get current user info
    c.execute('SELECT * FROM users WHERE id = ?', (session['user_id'], ))
    current_user = c.fetchone()

    # Get nearby players (same state and city)
    c.execute(
        '''SELECT id, name, age, city, state, area, role, availability 
                 FROM users WHERE state = ? AND city = ? AND id != ?''',
        (current_user[6], current_user[5], session['user_id']))
    nearby_players = c.fetchall()

    # Get coaching ads for user's area
    c.execute('SELECT * FROM coaching_ads WHERE state = ? AND city = ?',
              (current_user[6], current_user[5]))
    coaching_ads = c.fetchall()

    # Get live matches
    c.execute('SELECT * FROM live_matches ORDER BY created_at DESC LIMIT 5')
    live_matches = c.fetchall()

    # Get products
    c.execute('SELECT * FROM products ORDER BY created_at DESC LIMIT 10')
    products = c.fetchall()

    # Check if user can request admin access
    c.execute(
        'SELECT status FROM admin_requests WHERE user_id = ? ORDER BY requested_at DESC LIMIT 1',
        (session['user_id'], ))
    admin_request_status = c.fetchone()

    can_request_admin = not is_approved_admin(session['user_id']) and (
        not admin_request_status or admin_request_status[0] != 'pending')

    conn.close()

    return render_template('dashboard.html',
                           current_user=current_user,
                           nearby_players=nearby_players,
                           coaching_ads=coaching_ads,
                           live_matches=live_matches,
                           products=products,
                           can_request_admin=can_request_admin,
                           is_admin=is_approved_admin(session['user_id']))


@app.route('/admin')
def admin_dashboard():
    if 'admin' not in session:
        return redirect(url_for('admin_login'))

    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()

    # Get all data for admin
    c.execute('SELECT * FROM coaching_ads ORDER BY created_at DESC')
    coaching_ads = c.fetchall()

    c.execute('SELECT * FROM live_matches ORDER BY created_at DESC')
    live_matches = c.fetchall()

    c.execute('SELECT * FROM products ORDER BY created_at DESC')
    products = c.fetchall()

    c.execute('SELECT COUNT(*) FROM users')
    user_count = c.fetchone()[0]

    conn.close()

    return render_template('admin_dashboard.html',
                           coaching_ads=coaching_ads,
                           live_matches=live_matches,
                           products=products,
                           user_count=user_count)


@app.route('/add_coaching', methods=['POST'])
def add_coaching():
    if 'admin' not in session:
        return jsonify({'success': False, 'message': 'Unauthorized'})

    data = request.get_json()
    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()

    c.execute(
        '''INSERT INTO coaching_ads (title, description, area, city, state, coupon_code, discount)
                 VALUES (?, ?, ?, ?, ?, ?, ?)''',
        (data['title'], data['description'], data['area'], data['city'],
         data['state'], data['coupon_code'], data['discount']))

    conn.commit()
    conn.close()

    return jsonify({
        'success': True,
        'message': 'Coaching ad added successfully'
    })


@app.route('/add_live_match', methods=['POST'])
def add_live_match():
    if 'admin' not in session:
        return jsonify({'success': False, 'message': 'Unauthorized'})

    data = request.get_json()
    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()

    c.execute(
        '''INSERT INTO live_matches (title, youtube_url, description)
                 VALUES (?, ?, ?)''',
        (data['title'], data['youtube_url'], data['description']))

    conn.commit()
    conn.close()

    return jsonify({
        'success': True,
        'message': 'Live match added successfully'
    })


@app.route('/add_product', methods=['POST'])
def add_product():
    if 'admin' not in session:
        return jsonify({'success': False, 'message': 'Unauthorized'})

    data = request.get_json()
    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()

    c.execute(
        '''INSERT INTO products (name, description, price, image_url, affiliate_link)
                 VALUES (?, ?, ?, ?, ?)''',
        (data['name'], data['description'], data['price'], data['image_url'],
         data['affiliate_link']))

    conn.commit()
    conn.close()

    return jsonify({'success': True, 'message': 'Product added successfully'})


@app.route('/google_login')
def google_login():
    if not GOOGLE_CLIENT_ID or not GOOGLE_CLIENT_SECRET:
        flash('Google login is not configured. Please use regular login.')
        return redirect(url_for('login'))

    flow = create_oauth_flow()
    if not flow:
        flash('Google OAuth setup failed. Please use regular login.')
        return redirect(url_for('login'))

    try:
        authorization_url, state = flow.authorization_url(
            access_type='offline', include_granted_scopes='true')
        session['state'] = state
        return redirect(authorization_url)
    except Exception as e:
        flash(f'Google login error: {str(e)}. Please use regular login.')
        return redirect(url_for('login'))


@app.route('/oauth2callback')
def oauth2callback():
    try:
        flow = create_oauth_flow()
        if not flow:
            flash('Google OAuth not configured.')
            return redirect(url_for('login'))

        if 'state' not in session or request.args.get(
                'state') != session['state']:
            flash('Invalid state parameter.')
            return redirect(url_for('login'))

        authorization_response = request.url
        if authorization_response.startswith('http://'):
            authorization_response = authorization_response.replace(
                'http://', 'https://')

        flow.fetch_token(authorization_response=authorization_response)

        credentials = flow.credentials
        user_info_response = requests.get(
            'https://www.googleapis.com/oauth2/v2/userinfo',
            headers={'Authorization': f'Bearer {credentials.token}'})

        if user_info_response.status_code != 200:
            flash('Failed to get user information from Google.')
            return redirect(url_for('login'))

        user_info = user_info_response.json()
        email = user_info.get('email')
        name = user_info.get('name', '')

        if not email:
            flash('Could not get email from Google account.')
            return redirect(url_for('login'))

        conn = sqlite3.connect('cricket_app.db')
        c = conn.cursor()
        c.execute('SELECT id, username FROM users WHERE email = ?', (email, ))
        existing_user = c.fetchone()

        if existing_user:
            session['user_id'] = existing_user[0]
            session['username'] = existing_user[1]
            conn.close()
            flash('Successfully logged in with Google!')
            return redirect(url_for('dashboard'))
        else:
            username = email.split('@')[0]
            c.execute('SELECT id FROM users WHERE username = ?', (username, ))
            if c.fetchone():
                import time
                username = f"{username}_{int(time.time())}"

            c.execute(
                '''INSERT INTO users (username, email, password, name, age, city, state, area, role, availability, phone)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                (username, email, 'google_oauth', name, None, '', '', '',
                 'all-rounder', 'weekends', ''))

            user_id = c.lastrowid
            conn.commit()
            conn.close()

            session['user_id'] = user_id
            session['username'] = username
            session['new_google_user'] = True

            flash('Google account linked! Please complete your profile.')
            return redirect(url_for('complete_profile'))

    except Exception as e:
        flash(f'Google login failed: {str(e)}. Please try regular login.')
        return redirect(url_for('login'))


@app.route('/complete_profile', methods=['GET', 'POST'])
def complete_profile():
    if 'user_id' not in session or 'new_google_user' not in session:
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        data = request.get_json()
        age = data.get('age')
        city = data.get('city')
        state = data.get('state')
        area = data.get('area')
        role = data.get('role')
        availability = data.get('availability')
        phone = data.get('phone')

        conn = sqlite3.connect('cricket_app.db')
        c = conn.cursor()

        c.execute(
            '''UPDATE users SET age = ?, city = ?, state = ?, area = ?, role = ?, availability = ?, phone = ?
                     WHERE id = ?''',
            (age, city, state, area, role, availability, phone,
             session['user_id']))

        conn.commit()
        conn.close()

        session.pop('new_google_user', None)
        return jsonify({
            'success': True,
            'message': 'Profile completed successfully'
        })

    return render_template('complete_profile.html')


@app.route('/profile')
def profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()

    c.execute('SELECT * FROM users WHERE id = ?', (session['user_id'], ))
    user = c.fetchone()

    c.execute('SELECT COUNT(*) FROM connections WHERE following_id = ?',
              (session['user_id'], ))
    followers_count = c.fetchone()[0]

    c.execute('SELECT COUNT(*) FROM connections WHERE follower_id = ?',
              (session['user_id'], ))
    following_count = c.fetchone()[0]

    c.execute(
        '''SELECT u.*, c.connected_at FROM users u 
                 JOIN connections c ON u.id = c.following_id 
                 WHERE c.follower_id = ? 
                 ORDER BY c.connected_at DESC''', (session['user_id'], ))
    connections = c.fetchall()

    conn.close()

    return render_template('profile.html',
                           user=user,
                           followers_count=followers_count,
                           following_count=following_count,
                           connections_count=len(connections),
                           connections=connections)


@app.route('/update_profile', methods=['POST'])
def update_profile():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Unauthorized'})

    data = request.get_json()
    name = data.get('name')
    email = data.get('email')
    age = data.get('age')
    city = data.get('city')
    state = data.get('state')
    area = data.get('area')
    role = data.get('role')
    availability = data.get('availability')
    phone = data.get('phone')

    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()

    c.execute('SELECT id FROM users WHERE email = ? AND id != ?',
              (email, session['user_id']))
    if c.fetchone():
        conn.close()
        return jsonify({
            'success': False,
            'message': 'Email already taken by another user'
        })

    c.execute(
        '''UPDATE users SET name = ?, email = ?, age = ?, city = ?, state = ?, area = ?, role = ?, availability = ?, phone = ?
                 WHERE id = ?''', (name, email, age, city, state, area, role,
                                   availability, phone, session['user_id']))

    conn.commit()
    conn.close()

    return jsonify({
        'success': True,
        'message': 'Profile updated successfully'
    })


@app.route('/connect_player', methods=['POST'])
def connect_player():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Unauthorized'})

    data = request.get_json()
    player_id = data.get('player_id')

    if not player_id or player_id == session['user_id']:
        return jsonify({'success': False, 'message': 'Invalid player ID'})

    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()

    c.execute(
        'SELECT id FROM connections WHERE follower_id = ? AND following_id = ?',
        (session['user_id'], player_id))
    if c.fetchone():
        conn.close()
        return jsonify({'success': False, 'message': 'Already connected'})

    c.execute(
        'INSERT INTO connections (follower_id, following_id) VALUES (?, ?)',
        (session['user_id'], player_id))

    conn.commit()
    conn.close()

    return jsonify({'success': True, 'message': 'Connected successfully'})


@app.route('/delete_record', methods=['POST'])
def delete_record():
    if 'admin' not in session:
        return jsonify({'success': False, 'message': 'Unauthorized'})

    data = request.get_json()
    table = data.get('table')
    record_id = data.get('id')

    allowed_tables = ['users', 'coaching_ads', 'live_matches', 'products']
    if table not in allowed_tables:
        return jsonify({'success': False, 'message': 'Invalid table'})

    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()

    c.execute(f'DELETE FROM {table} WHERE id = ?', (record_id, ))
    conn.commit()
    conn.close()

    return jsonify({'success': True, 'message': 'Record deleted successfully'})


@app.route('/search_players')
def search_players():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Not logged in'})

    search_term = request.args.get('q', '').strip().lower()
    state_filter = request.args.get('state', '').strip().lower()
    city_filter = request.args.get('city', '').strip().lower()
    area_filter = request.args.get('area', '').strip().lower()
    role_filter = request.args.get('role', '').strip().lower()

    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()

    c.execute('SELECT state, city FROM users WHERE id = ?',
              (session['user_id'], ))
    current_user = c.fetchone()
    current_state = current_user[0] if current_user else ''
    current_city = current_user[1] if current_user else ''

    sql = '''SELECT id, name, age, city, state, area, role, availability 
             FROM users WHERE id != ?'''
    params = [session['user_id']]

    if search_term:
        sql += ''' AND (LOWER(name) LIKE ? OR LOWER(city) LIKE ? OR 
                        LOWER(area) LIKE ? OR LOWER(state) LIKE ?)'''
        search_pattern = f'%{search_term}%'
        params.extend(
            [search_pattern, search_pattern, search_pattern, search_pattern])

    if state_filter:
        sql += ' AND LOWER(state) LIKE ?'
        params.append(f'%{state_filter}%')

    if city_filter:
        sql += ' AND LOWER(city) LIKE ?'
        params.append(f'%{city_filter}%')

    if area_filter:
        sql += ' AND LOWER(area) LIKE ?'
        params.append(f'%{area_filter}%')

    if role_filter:
        sql += ' AND LOWER(role) = ?'
        params.append(role_filter)

    sql += ''' ORDER BY 
               CASE 
                   WHEN LOWER(state) = ? AND LOWER(city) = ? THEN 1
                   WHEN LOWER(state) = ? THEN 2
                   ELSE 3
               END,
               name ASC'''
    params.extend(
        [current_state.lower(),
         current_city.lower(),
         current_state.lower()])

    c.execute(sql, params)
    players = c.fetchall()
    conn.close()

    players_list = []
    for player in players:
        players_list.append({
            'id': player[0],
            'name': player[1],
            'age': player[2],
            'city': player[3],
            'state': player[4],
            'area': player[5],
            'role': player[6],
            'availability': player[7]
        })

    return jsonify({'success': True, 'players': players_list})


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))


if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)
