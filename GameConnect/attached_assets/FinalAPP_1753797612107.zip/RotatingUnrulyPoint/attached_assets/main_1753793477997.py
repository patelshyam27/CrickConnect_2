from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import os
from datetime import datetime
import google_auth_oauthlib.flow
import google.oauth2.credentials
import json
import requests

app = Flask(__name__)
app.secret_key = 'cricket_lovers_secret_key_2024'

# Google OAuth configuration
GOOGLE_CLIENT_ID = os.environ.get('GOOGLE_CLIENT_ID', '')
GOOGLE_CLIENT_SECRET = os.environ.get('GOOGLE_CLIENT_SECRET', '')

def create_oauth_flow():
    if GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET:
        # Generate redirect URI dynamically
        redirect_uri = url_for('oauth2callback', _external=True)
        if redirect_uri.startswith('http://'):
            redirect_uri = redirect_uri.replace('http://', 'https://')

        # Create OAuth configuration with dynamic redirect URI
        oauth_config = {
            "web": {
                "client_id": GOOGLE_CLIENT_ID,
                "client_secret": GOOGLE_CLIENT_SECRET,
                "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                "token_uri": "https://oauth2.googleapis.com/token",
                "redirect_uris": [redirect_uri]
            }
        }

        flow = google_auth_oauthlib.flow.Flow.from_client_config(
            oauth_config,
            scopes=[
                "https://www.googleapis.com/auth/userinfo.email",
                "openid", 
                "https://www.googleapis.com/auth/userinfo.profile",
            ]
        )
        flow.redirect_uri = redirect_uri
        return flow
    return None

# Database initialization
def init_db():
    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()

    # Users table
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        name TEXT NOT NULL,
        age INTEGER,
        city TEXT,
        state TEXT,
        area TEXT,
        role TEXT,
        availability TEXT,
        phone TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')
    
    # Migration: Add phone column if it doesn't exist
    try:
        c.execute('ALTER TABLE users ADD COLUMN phone TEXT')
        print("Added phone column to users table")
    except sqlite3.OperationalError:
        # Column already exists
        pass

    # Coaching ads table
    c.execute('''CREATE TABLE IF NOT EXISTS coaching_ads (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT,
        area TEXT,
        city TEXT,
        state TEXT,
        coupon_code TEXT,
        discount TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')

    # Live matches table
    c.execute('''CREATE TABLE IF NOT EXISTS live_matches (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        youtube_url TEXT NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')

    # Products table
    c.execute('''CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        price REAL,
        image_url TEXT,
        affiliate_link TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')

    # Connections table for tracking followers/following
    c.execute('''CREATE TABLE IF NOT EXISTS connections (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        follower_id INTEGER,
        following_id INTEGER,
        connected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (follower_id) REFERENCES users (id),
        FOREIGN KEY (following_id) REFERENCES users (id),
        UNIQUE(follower_id, following_id)
    )''')

    # Visitor tracking table
    c.execute('''CREATE TABLE IF NOT EXISTS visitors (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ip_address TEXT,
        user_agent TEXT,
        visited_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')

    conn.commit()
    conn.close()

# Routes
@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))

    # Track visitor
    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()

    # Get visitor IP and user agent
    visitor_ip = request.remote_addr
    user_agent = request.headers.get('User-Agent', '')

    # Check if this IP visited in the last hour to avoid duplicate counting
    c.execute('''SELECT id FROM visitors WHERE ip_address = ? 
                 AND visited_at > datetime('now', '-1 hour')''', (visitor_ip,))
    recent_visit = c.fetchone()

    if not recent_visit:
        # Add new visitor entry
        c.execute('INSERT INTO visitors (ip_address, user_agent) VALUES (?, ?)', 
                  (visitor_ip, user_agent))

    # Get total visitor count (unique IPs in last 30 days)
    c.execute('''SELECT COUNT(DISTINCT ip_address) FROM visitors 
                 WHERE visited_at > datetime('now', '-30 days')''')
    visitor_count = c.fetchone()[0]

    # Get total user count
    c.execute('SELECT COUNT(*) FROM users')
    user_count = c.fetchone()[0]

    # Get total visits today
    c.execute('''SELECT COUNT(*) FROM visitors 
                 WHERE date(visited_at) = date('now')''')
    today_visits = c.fetchone()[0]

    # Get coaching offers with discounts for homepage
    c.execute('''SELECT * FROM coaching_ads 
                 WHERE coupon_code IS NOT NULL AND coupon_code != '' 
                 AND discount IS NOT NULL AND discount != ''
                 ORDER BY created_at DESC LIMIT 6''')
    coaching_offers = c.fetchall()

    conn.commit()
    conn.close()

    return render_template('index.html', 
                         visitor_count=visitor_count,
                         user_count=user_count,
                         today_visits=today_visits,
                         coaching_offers=coaching_offers)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        data = request.get_json()
        username = data.get('username')
        email = data.get('email')
        password = data.get('password')
        name = data.get('name')
        age = data.get('age')
        city = data.get('city')
        state = data.get('state')
        area = data.get('area')
        role = data.get('role')
        availability = data.get('availability')
        phone = data.get('phone')

        conn = sqlite3.connect('cricket_app.db')
        c = conn.cursor()

        # Check if user exists
        c.execute('SELECT id FROM users WHERE username = ? OR email = ?', (username, email))
        if c.fetchone():
            conn.close()
            return jsonify({'success': False, 'message': 'User already exists'})

        # Create user
        hashed_password = generate_password_hash(password)
        c.execute('''INSERT INTO users (username, email, password, name, age, city, state, area, role, availability, phone)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                  (username, email, hashed_password, name, age, city, state, area, role, availability, phone))

        user_id = c.lastrowid
        conn.commit()
        conn.close()

        session['user_id'] = user_id
        session['username'] = username
        return jsonify({'success': True, 'message': 'Registration successful'})

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')

        conn = sqlite3.connect('cricket_app.db')
        c = conn.cursor()
        c.execute('SELECT id, username, password FROM users WHERE username = ? OR email = ?', (username, username))
        user = c.fetchone()
        conn.close()

        if user and check_password_hash(user[2], password):
            session['user_id'] = user[0]
            session['username'] = user[1]
            return jsonify({'success': True, 'message': 'Login successful'})

        return jsonify({'success': False, 'message': 'Invalid credentials'})

    return render_template('login.html')

@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        password = request.form.get('password')
        if password == '271106':
            session['admin'] = True
            return redirect(url_for('admin_dashboard'))
        flash('Invalid admin password')

    return render_template('admin_login.html')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()

    # Get current user info
    c.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],))
    current_user = c.fetchone()

    # Get nearby players (same state and city)
    c.execute('''SELECT id, name, age, city, state, area, role, availability 
                 FROM users WHERE state = ? AND city = ? AND id != ?''',
              (current_user[6], current_user[5], session['user_id']))
    nearby_players = c.fetchall()

    # Get coaching ads for user's area
    c.execute('SELECT * FROM coaching_ads WHERE state = ? AND city = ?', (current_user[6], current_user[5]))
    coaching_ads = c.fetchall()

    # Get live matches
    c.execute('SELECT * FROM live_matches ORDER BY created_at DESC LIMIT 5')
    live_matches = c.fetchall()

    # Get products
    c.execute('SELECT * FROM products ORDER BY created_at DESC LIMIT 10')
    products = c.fetchall()

    conn.close()

    return render_template('dashboard.html', 
                         current_user=current_user, 
                         nearby_players=nearby_players,
                         coaching_ads=coaching_ads,
                         live_matches=live_matches,
                         products=products)

@app.route('/admin')
def admin_dashboard():
    if 'admin' not in session:
        return redirect(url_for('admin_login'))

    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()

    # Get all data for admin
    c.execute('SELECT * FROM coaching_ads ORDER BY created_at DESC')
    coaching_ads = c.fetchall()

    c.execute('SELECT * FROM live_matches ORDER BY created_at DESC')
    live_matches = c.fetchall()

    c.execute('SELECT * FROM products ORDER BY created_at DESC')
    products = c.fetchall()

    c.execute('SELECT COUNT(*) FROM users')
    user_count = c.fetchone()[0]

    conn.close()

    return render_template('admin_dashboard.html',
                         coaching_ads=coaching_ads,
                         live_matches=live_matches,
                         products=products,
                         user_count=user_count)

@app.route('/add_coaching', methods=['POST'])
def add_coaching():
    if 'admin' not in session:
        return jsonify({'success': False, 'message': 'Unauthorized'})

    data = request.get_json()
    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()

    c.execute('''INSERT INTO coaching_ads (title, description, area, city, state, coupon_code, discount)
                 VALUES (?, ?, ?, ?, ?, ?, ?)''',
              (data['title'], data['description'], data['area'], data['city'], 
               data['state'], data['coupon_code'], data['discount']))

    conn.commit()
    conn.close()

    return jsonify({'success': True, 'message': 'Coaching ad added successfully'})

@app.route('/add_live_match', methods=['POST'])
def add_live_match():
    if 'admin' not in session:
        return jsonify({'success': False, 'message': 'Unauthorized'})

    data = request.get_json()
    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()

    c.execute('''INSERT INTO live_matches (title, youtube_url, description)
                 VALUES (?, ?, ?)''',
              (data['title'], data['youtube_url'], data['description']))

    conn.commit()
    conn.close()

    return jsonify({'success': True, 'message': 'Live match added successfully'})

@app.route('/add_product', methods=['POST'])
def add_product():
    if 'admin' not in session:
        return jsonify({'success': False, 'message': 'Unauthorized'})

    data = request.get_json()
    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()

    c.execute('''INSERT INTO products (name, description, price, image_url, affiliate_link)
                 VALUES (?, ?, ?, ?, ?)''',
              (data['name'], data['description'], data['price'], 
               data['image_url'], data['affiliate_link']))

    conn.commit()
    conn.close()

    return jsonify({'success': True, 'message': 'Product added successfully'})

@app.route('/google_login')
def google_login():
    # Check if Google OAuth is configured
    if not GOOGLE_CLIENT_ID or not GOOGLE_CLIENT_SECRET:
        flash('Google login is not configured. Please use regular login.')
        return redirect(url_for('login'))

    flow = create_oauth_flow()
    if not flow:
        flash('Google OAuth setup failed. Please use regular login.')
        return redirect(url_for('login'))

    try:
        authorization_url, state = flow.authorization_url(
            access_type='offline',
            include_granted_scopes='true'
        )
        session['state'] = state
        return redirect(authorization_url)
    except Exception as e:
        flash(f'Google login error: {str(e)}. Please use regular login.')
        return redirect(url_for('login'))

@app.route('/oauth2callback')
def oauth2callback():
    try:
        flow = create_oauth_flow()
        if not flow:
            flash('Google OAuth not configured.')
            return redirect(url_for('login'))

        # Verify state parameter
        if 'state' not in session or request.args.get('state') != session['state']:
            flash('Invalid state parameter.')
            return redirect(url_for('login'))

        # Handle the authorization response
        authorization_response = request.url
        if authorization_response.startswith('http://'):
            authorization_response = authorization_response.replace('http://', 'https://')

        flow.fetch_token(authorization_response=authorization_response)

        # Get user info from Google
        credentials = flow.credentials
        user_info_response = requests.get(
            'https://www.googleapis.com/oauth2/v2/userinfo',
            headers={'Authorization': f'Bearer {credentials.token}'}
        )

        if user_info_response.status_code != 200:
            flash('Failed to get user information from Google.')
            return redirect(url_for('login'))

        user_info = user_info_response.json()
        email = user_info.get('email')
        name = user_info.get('name', '')

        if not email:
            flash('Could not get email from Google account.')
            return redirect(url_for('login'))

        # Check if user exists in database
        conn = sqlite3.connect('cricket_app.db')
        c = conn.cursor()
        c.execute('SELECT id, username FROM users WHERE email = ?', (email,))
        existing_user = c.fetchone()

        if existing_user:
            # User exists, log them in
            session['user_id'] = existing_user[0]
            session['username'] = existing_user[1]
            conn.close()
            flash('Successfully logged in with Google!')
            return redirect(url_for('dashboard'))
        else:
            # New user, create account
            username = email.split('@')[0]  # Use email prefix as username
            # Make username unique if it already exists
            c.execute('SELECT id FROM users WHERE username = ?', (username,))
            if c.fetchone():
                import time
                username = f"{username}_{int(time.time())}"

            # Create user with minimal required info
            c.execute('''INSERT INTO users (username, email, password, name, age, city, state, area, role, availability, phone)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                      (username, email, 'google_oauth', name, None, '', '', '', 'all-rounder', 'weekends', ''))

            user_id = c.lastrowid
            conn.commit()
            conn.close()

            session['user_id'] = user_id
            session['username'] = username
            session['new_google_user'] = True

            flash('Google account linked! Please complete your profile.')
            return redirect(url_for('complete_profile'))

    except Exception as e:
        flash(f'Google login failed: {str(e)}. Please try regular login.')
        return redirect(url_for('login'))

@app.route('/complete_profile', methods=['GET', 'POST'])
def complete_profile():
    if 'user_id' not in session or 'new_google_user' not in session:
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        data = request.get_json()
        age = data.get('age')
        city = data.get('city')
        state = data.get('state')
        area = data.get('area')
        role = data.get('role')
        availability = data.get('availability')
        phone = data.get('phone')

        conn = sqlite3.connect('cricket_app.db')
        c = conn.cursor()

        c.execute('''UPDATE users SET age = ?, city = ?, state = ?, area = ?, role = ?, availability = ?, phone = ?
                     WHERE id = ?''',
                  (age, city, state, area, role, availability, phone, session['user_id']))

        conn.commit()
        conn.close()

        session.pop('new_google_user', None)
        return jsonify({'success': True, 'message': 'Profile completed successfully'})

    return render_template('complete_profile.html')

@app.route('/database_viewer')
def database_viewer():
    if 'admin' not in session:
        return redirect(url_for('admin_login'))

    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()

    # Get all users
    c.execute('SELECT * FROM users')
    users = c.fetchall()

    # Get all coaching ads
    c.execute('SELECT * FROM coaching_ads')
    coaching_ads = c.fetchall()

    # Get all live matches
    c.execute('SELECT * FROM live_matches')
    live_matches = c.fetchall()

    # Get all products
    c.execute('SELECT * FROM products')
    products = c.fetchall()

    # Get table schemas
    tables_info = {}

    # Users table schema
    c.execute("PRAGMA table_info(users)")
    tables_info['users'] = c.fetchall()

    # Coaching ads table schema
    c.execute("PRAGMA table_info(coaching_ads)")
    tables_info['coaching_ads'] = c.fetchall()

    # Live matches table schema
    c.execute("PRAGMA table_info(live_matches)")
    tables_info['live_matches'] = c.fetchall()

    # Products table schema
    c.execute("PRAGMA table_info(products)")
    tables_info['products'] = c.fetchall()

    conn.close()

    return render_template('database_viewer.html', 
                         users=users,
                         coaching_ads=coaching_ads,
                         live_matches=live_matches,
                         products=products,
                         tables_info=tables_info)

@app.route('/profile')
def profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()

    # Get current user info
    c.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],))
    user = c.fetchone()

    # Get followers count
    c.execute('SELECT COUNT(*) FROM connections WHERE following_id = ?', (session['user_id'],))
    followers_count = c.fetchone()[0]

    # Get following count
    c.execute('SELECT COUNT(*) FROM connections WHERE follower_id = ?', (session['user_id'],))
    following_count = c.fetchone()[0]

    # Get connections (people user is following)
    c.execute('''SELECT u.*, c.connected_at FROM users u 
                 JOIN connections c ON u.id = c.following_id 
                 WHERE c.follower_id = ? 
                 ORDER BY c.connected_at DESC''', (session['user_id'],))
    connections = c.fetchall()

    conn.close()

    return render_template('profile.html', 
                         user=user,
                         followers_count=followers_count,
                         following_count=following_count,
                         connections_count=len(connections),
                         connections=connections)

@app.route('/update_profile', methods=['POST'])
def update_profile():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Unauthorized'})

    data = request.get_json()
    name = data.get('name')
    email = data.get('email')
    age = data.get('age')
    city = data.get('city')
    state = data.get('state')
    area = data.get('area')
    role = data.get('role')
    availability = data.get('availability')
    phone = data.get('phone')

    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()

    # Check if email is already taken by another user
    c.execute('SELECT id FROM users WHERE email = ? AND id != ?', (email, session['user_id']))
    if c.fetchone():
        conn.close()
        return jsonify({'success': False, 'message': 'Email already taken by another user'})

    # Update user profile
    c.execute('''UPDATE users SET name = ?, email = ?, age = ?, city = ?, state = ?, area = ?, role = ?, availability = ?, phone = ?
                 WHERE id = ?''',
              (name, email, age, city, state, area, role, availability, phone, session['user_id']))

    conn.commit()
    conn.close()

    return jsonify({'success': True, 'message': 'Profile updated successfully'})

@app.route('/connect_player', methods=['POST'])
def connect_player():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Unauthorized'})

    data = request.get_json()
    player_id = data.get('player_id')

    if not player_id or player_id == session['user_id']:
        return jsonify({'success': False, 'message': 'Invalid player ID'})

    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()

    # Check if connection already exists
    c.execute('SELECT id FROM connections WHERE follower_id = ? AND following_id = ?', 
              (session['user_id'], player_id))
    if c.fetchone():
        conn.close()
        return jsonify({'success': False, 'message': 'Already connected'})

    # Create connection
    c.execute('INSERT INTO connections (follower_id, following_id) VALUES (?, ?)',
              (session['user_id'], player_id))

    conn.commit()
    conn.close()

    return jsonify({'success': True, 'message': 'Connected successfully'})

@app.route('/delete_record', methods=['POST'])
def delete_record():
    if 'admin' not in session:
        return jsonify({'success': False, 'message': 'Unauthorized'})

    data = request.get_json()
    table = data.get('table')
    record_id = data.get('id')

    # Validate table name to prevent SQL injection
    allowed_tables = ['users', 'coaching_ads', 'live_matches', 'products']
    if table not in allowed_tables:
        return jsonify({'success': False, 'message': 'Invalid table'})

    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()

    c.execute(f'DELETE FROM {table} WHERE id = ?', (record_id,))
    conn.commit()
    conn.close()

    return jsonify({'success': True, 'message': 'Record deleted successfully'})

@app.route('/search_players')
def search_players():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Not logged in'})

    # Get search parameters
    search_term = request.args.get('q', '').strip().lower()
    state_filter = request.args.get('state', '').strip().lower()
    city_filter = request.args.get('city', '').strip().lower()
    area_filter = request.args.get('area', '').strip().lower()
    role_filter = request.args.get('role', '').strip().lower()

    conn = sqlite3.connect('cricket_app.db')
    c = conn.cursor()

    # Get current user info for location-based sorting
    c.execute('SELECT state, city FROM users WHERE id = ?', (session['user_id'],))
    current_user = c.fetchone()
    current_state = current_user[0] if current_user else ''
    current_city = current_user[1] if current_user else ''

    # Build dynamic search query
    sql = '''SELECT id, name, age, city, state, area, role, availability 
             FROM users WHERE id != ?'''
    params = [session['user_id']]

    # Add search conditions
    if search_term:
        sql += ''' AND (LOWER(name) LIKE ? OR LOWER(city) LIKE ? OR 
                        LOWER(area) LIKE ? OR LOWER(state) LIKE ?)'''
        search_pattern = f'%{search_term}%'
        params.extend([search_pattern, search_pattern, search_pattern, search_pattern])

    if state_filter:
        sql += ' AND LOWER(state) LIKE ?'
        params.append(f'%{state_filter}%')

    if city_filter:
        sql += ' AND LOWER(city) LIKE ?'
        params.append(f'%{city_filter}%')

    if area_filter:
        sql += ' AND LOWER(area) LIKE ?'
        params.append(f'%{area_filter}%')

    if role_filter:
        sql += ' AND LOWER(role) = ?'
        params.append(role_filter)

    # Order by proximity (same state/city first), then by name
    sql += ''' ORDER BY 
               CASE 
                   WHEN LOWER(state) = ? AND LOWER(city) = ? THEN 1
                   WHEN LOWER(state) = ? THEN 2
                   ELSE 3
               END,
               name ASC'''
    params.extend([current_state.lower(), current_city.lower(), current_state.lower()])

    c.execute(sql, params)
    players = c.fetchall()
    conn.close()

    # Format results
    players_list = []
    for player in players:
        players_list.append({
            'id': player[0],
            'name': player[1],
            'age': player[2],
            'city': player[3],
            'state': player[4],
            'area': player[5],
            'role': player[6],
            'availability': player[7]
        })

    return jsonify({'success': True, 'players': players_list})

@app.route('/google_status')
def google_status():
    if 'admin' not in session:
        return jsonify({'error': 'Unauthorized'}), 403

    return jsonify({
        'client_id_configured': bool(GOOGLE_CLIENT_ID),
        'client_secret_configured': bool(GOOGLE_CLIENT_SECRET),
        'client_id_preview': GOOGLE_CLIENT_ID[:20] + '...' if GOOGLE_CLIENT_ID else 'Not set'
    })

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)